from behave import When, Then, Given


from Login_page import GitHubLogin
from Util_browser import globalObj
from HomePage import GitHubHome
#
#global home, globalObj,login
# home = GitHubHome(globalObj.realDriver)

@When(u'I navigate to the " {url} "')
def step_impl(context, url):
    global home, globalObj, login
    # home = GitHubHome(globalObj.realDriver)
    # login = GitHubLogin(globalObj.realDriver)
    # print 'Navigating to', url
    # globalObj.NavigateToFollowingUrl(url_to_navigate=url)


@When(U'I attempt to login with Invalid Creditional')
def step_impl(context):
    print 'I attempt to login with invalid credentials'
    # home.Clicksign_In()
    # login.InvalidLogin("fakeuser","fakepswd")

@Then(u'Login should not be successful')
def step_impl(context):
    print"Invalid userid and pswd validation"
    # login.VerifyLoginFailed()


@When(u'I attempt to login with Valid credtional')
def step_impl(context):
    print "valid userid and pswd validation"
    # home.Clicksign_In()
    # login.ValidLogin("chitrasankpal@gmail.com","Chintu@cbadagi27")

@Then(u'Login should be successful')
def step_impl(context):
   # login.Loginsuccessful()
    print "login with valid userid and pswd was successful"

