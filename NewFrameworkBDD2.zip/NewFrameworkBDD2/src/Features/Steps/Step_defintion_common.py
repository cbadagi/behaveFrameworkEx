from HomePage import GitHubHome
from Login_page import GitHubLogin
from Util_browser import globalObj
from behave import Given, Then, When
import time

@Given(u'I Launch the "{Browser_type}" Browser')
def step_impl(context, Browser_type):
    print 'Launching following browser', Browser_type
    # globalObj.InvokeBrowser(browser_to_invoke=Browser_type)
    # time.sleep(5)


@Then(u'Close the browser')
def step_impl(context):
    print 'I close browser'
    #globalObj.CloseCurrentBrowser()



