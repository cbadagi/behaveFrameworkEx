from selenium import webdriver
import os
import time


class BrowserFacility:
    realDriver = None

    def __init__(self):
        pass

    def InvokeBrowser(self, browser_to_invoke):
        if 'Chrome' == browser_to_invoke:
            chromedriver_path = "../browser_driver/chromedriver.exe"
            os.environ["webdriver.chrome.driver"] = chromedriver_path
            self.realDriver = webdriver.Chrome(chromedriver_path)
        elif 'firefox' == browser_to_invoke:
            firefoxdriver_path = "../browser_driver/geckodriver.exe"
            os.environ["webdriver.gecko.driver"] = firefoxdriver_path
            self.realDriver = webdriver.Firefox(executable_path=firefoxdriver_path)
        else:
            assert 'This browser type not supported ', browser_to_invoke

    def CloseCurrentBrowser(self):
        self.realDriver.close()
        self.realDriver.quit()

    def NavigateToFollowingUrl(self,url_to_navigate):
        self.realDriver.get(url_to_navigate)
        self.realDriver.maximize_window()
        time.sleep(5)



globalObj = BrowserFacility()
