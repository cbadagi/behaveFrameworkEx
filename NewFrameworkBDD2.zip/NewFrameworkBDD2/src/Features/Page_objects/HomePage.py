from selenium.webdriver.common.keys import Keys
from selenium import webdriver
import time

class GitHubHome:
    '''Class has the locator for the class and methods related of the home page '''
    localDriver = None

    def __init__(self, driver):
        self.localDriver = driver

        # locators
    Lnk_sign_In = "a[class='HeaderMenu-link no-underline mr-3']"


    def Clicksign_In(self):
        self.localDriver.find_element_by_css_selector(self.Lnk_sign_In).click()
        time.sleep(4)


