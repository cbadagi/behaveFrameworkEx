
from selenium import webdriver
from selenium.webdriver.common.keys import Keys

class GitHubLogin:
    localDriver = None
    def __init__(self,driver):
        self.localDriver=driver
#locators
    LogIn  ='login_field'   #ID
    Pswd = 'password'       #ID
    SignIN_Btn= "input[value='Sign in']"
    Invalid_login_error = "div[class='flash flash-full flash-error']"
    validLogin_Img_BellIcon = "svg[class='octicon octicon-bell']"

    def InvalidLogin(self,userID,pswd):
        self.localDriver.find_element_by_id(self.LogIn).send_keys(userID)
        self.localDriver.find_element_by_id(self.Pswd).send_keys(pswd)
        self.localDriver.find_element_by_css_selector(self.SignIN_Btn).click()

    def VerifyLoginFailed(self):
       if  not self.localDriver.find_element_by_css_selector(self.Invalid_login_error).is_displayed():
            assert False,"Error - Able to login with invalid username and password"

    def ValidLogin(self,userid,pswd):
        self.localDriver.find_element_by_id(self.LogIn).send_keys(userid)
        self.localDriver.find_element_by_id(self.Pswd).send_keys(pswd)
        self.localDriver.find_element_by_css_selector(self.SignIN_Btn).click()

    def Loginsuccessful(self):
        if  not self.localDriver.find_element_by_css_selector(self.validLogin_Img_BellIcon).is_displayed():
            assert True,"Error,unable to login with valid user and pswd"
        