import sys
from json2html import *
from behave import __main__ as runner_with_options
import shutil
import allure_behave

if __name__ == '__main__':
    sys.stdout.flush()

    # reporting related items
    reporting_folder_name = 'reporting_folder_json_html'
    shutil.rmtree(reporting_folder_name, ignore_errors=True)
    reportingRelated = ' -f allure_behave.formatter:AllureFormatter -o %reporting-folder-json-html% ' # + reporting_folder_name + ' '
    tagList = ' --tags=data_driven '
    featureFilePath = ' Features_file_folder/Scenario_login.feature '  # specific feature file
    commonRunnerOptions = ' --no-capture --no-capture-stderr -f plain '
    #fullRunnerOptions = featureFilePath + commonRunnerOptions
    fullRunnerOptions = featureFilePath + commonRunnerOptions +  reportingRelated
    print fullRunnerOptions
    runner_with_options.main(fullRunnerOptions)
